package mainmod;

import Dao.HospitalServiceImpl;
import Entity.*;

import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an instance of the HospitalServiceImpl class
        HospitalServiceImpl hospitalService = new HospitalServiceImpl();

        // Trigger all the methods in the service implementation class
        try {
            int option;
            do {
                // Display menu options
                System.out.println("\nMenu:");
                System.out.println("1. Get appointment by ID");
                System.out.println("2. Get appointments for a patient");
                System.out.println("3. Get appointments for a doctor");
                System.out.println("4. Schedule appointment");
                System.out.println("5. Update appointment");
                System.out.println("6. Cancel appointment");
                System.out.println("0. Exit");

                System.out.print("Enter your choice: ");
                option = scanner.nextInt();
                switch(option) {
                case 1:
			System.out.println("Enter appointment ID to get appointment details:");
            int appointmentId = scanner.nextInt();
            Appointment appointmentById = hospitalService.getAppointmentById(appointmentId);
            if (appointmentById != null) {
                System.out.println("Appointment details by ID:");
                System.out.println("Appointment ID: " + appointmentById.getAppointmentId());
                System.out.println("Patient ID: " + appointmentById.getPatientId());
                System.out.println("Doctor ID: " + appointmentById.getDoctorId());
                System.out.println("Appointment Date: " + appointmentById.getAppointmentDate());
                System.out.println("Description: " + appointmentById.getDescription());
            } else {
                System.out.println("Appointment not found.");
                }
                break;

                case 2:
                    System.out.println("Enter patient ID to get appointments for the patient:");
                    int patientId = scanner.nextInt();
                    List<Appointment> patientAppointments = hospitalService.getAppointmentsForPatient(patientId);

                    if(patientAppointments.isEmpty()) {
                        System.out.println("No appointments found for the patient with ID: " + patientId);
                    } else {
                        System.out.println("Appointments for the patient with ID " + patientId + ":");
                    for(Appointment appointment : patientAppointments) {
                        System.out.println("Appointment ID: " + appointment.getAppointmentId());
                        System.out.println("Doctor ID: " + appointment.getDoctorId());
                        System.out.println("Appointment Date: " + appointment.getAppointmentDate());
                        System.out.println("Description: " + appointment.getDescription());
                        System.out.println("-----------------------------");
}
    }
    break;

                case 3:
                    System.out.println("Enter doctor ID to get appointments for the doctor:");
                    int doctorId = scanner.nextInt();
                    List<Appointment> doctorAppointments = hospitalService.getAppointmentsForDoctor(doctorId);

                    if(doctorAppointments.isEmpty()) {
                        System.out.println("No appointments found for the doctor with ID: " + doctorId);
                    } else {
                        System.out.println("Appointments for the doctor with ID " + doctorId + ":");
                    for(Appointment appointment : doctorAppointments) {
                        System.out.println("Appointment ID: " + appointment.getAppointmentId());
                        System.out.println("Patient ID: " + appointment.getPatientId());
                        System.out.println("Appointment Date: " + appointment.getAppointmentDate());
                        System.out.println("Description: " + appointment.getDescription());
                        System.out.println("-----------------------------");
                }
            }
            break;

                    case 4:
			// Schedule appointment
                        System.out.println("\nEnter details to schedule appointment:");
                        System.out.print("Enter appointment ID: ");
                        int newAppointmentId = scanner.nextInt();
                        System.out.print("Enter patient ID: ");
                        int newPatientId = scanner.nextInt();
                        System.out.print("Enter doctor ID: ");
                        int newDoctorId = scanner.nextInt();
                        System.out.print("Enter appointment date (YYYY-MM-DD): ");
                        String newAppointmentDate = scanner.next();
                        System.out.print("Enter appointment description: ");
                        String newAppointmentDescription = scanner.next();
                        Appointment newAppointment = new Appointment(newAppointmentId, newPatientId, newDoctorId, newAppointmentDate, newAppointmentDescription);
                        boolean isScheduled = hospitalService.scheduleAppointment(newAppointment);
                        if (isScheduled) {
                            System.out.println("Appointment scheduled successfully.");
                        } else {
                            System.out.println("Failed to schedule appointment.");
                        }
                        break;
                    case 5:
                        // Update appointment
			System.out.println("\nEnter details to update appointment:");
                        System.out.print("Enter appointment ID to update: ");
                        int appointmentToUpdateId = scanner.nextInt();
                        System.out.print("Enter new appointment date (YYYY-MM-DD): ");
                        String updatedAppointmentDate = scanner.next();
                        System.out.print("Enter new appointment description: ");
                        String updatedAppointmentDescription = scanner.next();
                        Appointment appointmentToUpdate = new Appointment(appointmentToUpdateId, 0, 0, updatedAppointmentDate, updatedAppointmentDescription);
                        boolean isUpdated = hospitalService.updateAppointment(appointmentToUpdate);
                        if (isUpdated) {
                            System.out.println("Appointment updated successfully.");
                        } else {
                            System.out.println("Failed to update appointment.");
                        }
                        break;
                    case 6:
                        // Cancel appointment
                        System.out.println("\nEnter appointment ID to cancel appointment:");
                        int appointmentIdToCancel = scanner.nextInt();
                        boolean isCancelled = hospitalService.cancelAppointment(appointmentIdToCancel);
                        if (isCancelled) {
                            System.out.println("Appointment cancelled successfully.");
                        } else {
                            System.out.println("Failed to cancel appointment.");
                        }
                        break;
                        case 0:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } while (option != 0);

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}