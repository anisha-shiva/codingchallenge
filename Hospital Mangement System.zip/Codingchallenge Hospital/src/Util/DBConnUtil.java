package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnUtil {
    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            Properties properties = DBPropertyUtil.loadProperties("C:\\Users\\Aarthi\\Downloads\\Java\\Hospital\\Hospital Management\\Hexaware Coding Challenge\\Codingchallenge Hospital\\Database.properties");
            String connectionString = DBPropertyUtil.getPropertyString(properties);
            try {
                Class.forName("com.mysql.cj.jdbc.Driver"); // Load the JDBC driver
                connection = DriverManager.getConnection(connectionString);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                throw new SQLException("Failed to load JDBC driver");
            }
        }
        return connection;
    }
}
